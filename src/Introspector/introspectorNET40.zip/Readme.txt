Introspector Source Code
========================

The resource (*.ico and *.png) files are not included with the source code.
These files come with Visual Studio and can be found at:

C:\Program Files\Microsoft Visual Studio 8\Common7\VS2005ImageLibrary\VS2005ImageLibrary.zip

(Replace C:\ with the drive where Visual Studio 2005 is installed.)

This software is provided with absolutely no warranties. All use is at your
own risk.